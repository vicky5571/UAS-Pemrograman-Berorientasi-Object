from university import University
from student import Student
from professor import Professor
from course import Course
from building import Building
from room import Room

if __name__ == "__main__":

    University.menu()
